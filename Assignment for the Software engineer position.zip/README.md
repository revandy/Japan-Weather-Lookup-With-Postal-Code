# JAPAN WEATHER LOOKUP WITH POSTAL CODE


This is an implementation project using 3 APIs.

  - metaweather.com
  - zippopotam.us
  - ip-api.com

Click here for video
[![Alt text for your video](https://cdn3.iconfinder.com/data/icons/cloud-computing-glyphs-vol-2/52/game__video__Play__playbutton__weather__cloud__computing-512.png)](https://streamable.com/uw58t2)
License
----

MIT


**Free Software, Hell Yeah!**
